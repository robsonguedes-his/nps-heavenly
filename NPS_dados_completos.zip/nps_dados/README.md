# Base de dados NPS — Alunos (para o dashboard em HTML/VS Code)

Exportação completa da planilha **"NPS - Alunos 1 (corrigida e unificada).xlsx"**
(nomes já padronizados pela base do RH, duplicidades tratadas, e o NPS de família
já dividido por segmento/unidade via CPF). Os valores aqui são os **resultados
calculados** das fórmulas da planilha (não as fórmulas em si), prontos para
consumir direto em JavaScript.

Também incluído: `source_planilha.xlsx`, a planilha original recalculada — use
como conferência ou se precisar visualizar algo pontualmente no Excel.

## Estrutura das pastas

- **`/tabelas/`** — as tabelas "de lista" (uma linha por professor, por aluno,
  por resposta etc.) exportadas como **array de objetos**, já com o nome de
  cada coluna como chave. É o formato mais fácil de consumir em JS
  (`data.map(r => r["Professor"])`, por exemplo).
- **Arquivos na raiz** (`00-Mapa.json`, `02-Painel-Eixos.json`, etc.) — **todas
  as 32 abas da planilha**, sem exceção, exportadas como grade bruta (array de
  arrays, uma posição por célula, na ordem em que aparecem no Excel). Use estes
  para as abas de painel/resumo que têm layout de múltiplas tabelas na mesma
  aba (título + tabela 1 + tabela 2, etc.), onde uma linha só de cabeçalho não
  faz sentido.
- **`manifest.json`** — lista todas as 32 abas, o arquivo correspondente,
  dimensões (linhas x colunas) e, quando existe, a linha de cabeçalho usada
  em `/tabelas/`.

## Abas disponíveis como objetos (`/tabelas/`)

| Aba | Registros | Conteúdo |
|---|---|---|
| 03-Prof-Triangulação | 140 | Nota por professor cruzando autoavaliação, coordenação e alunos |
| 09-Feedback-Professor | 154 | Pauta de feedback por professor (1 achado por eixo) |
| 10-Prof-Mais-Citados / (2) | 54 cada | Ranking de professores mais citados pelos alunos |
| 12-Idioma-Alinhamento | 18 | Alinhamento de avaliação de idiomas |
| 04-Calibragem-Coord | 18 | Calibragem entre coordenadores |
| 05-Tutoria-4-Visoes | 44 | Tutoria sob 4 óticas (aluno, tutor, coordenação, família) |
| alun-Usuários_V2, alun-Tutores, Alun-Respostas, Alun-Perguntas, Alun-Rascunhos, Alun-Acessos | — | Dados brutos da pesquisa dos alunos |
| coor-usuarios, coor-perguntas, coor-resposta | — | Dados brutos da pesquisa de coordenação |
| auto-perguntas, auto-respostas | — | Dados brutos da autoavaliação dos professores |
| fam-dados, fam-pdi, fam-pergunta, fam-resposta | — | Dados brutos da pesquisa das famílias (fam-resposta já contém as colunas **"Segmento via CPF"** e **"Unidade via CPF"**, resolvidas) |
| 01-Integração-Perguntas | 34 | Mapa de perguntas por pesquisa/eixo |

## Abas de painel/resumo (só na raiz, formato bruto)

- **02-Painel-Eixos** — o painel consolidado por eixo (visão executiva).
- **06-Por-Segmento** e **13-Fam-Por-Segmento** — NPS e médias por segmento
  (Ensino Infantil/Fund. I/Fund. II/Médio) e por unidade (Kinder/Asa
  Norte/High), incluindo o NPS de família já corrigido.
- **08-Incongruências** — os erros originalmente identificados e o status de
  cada um (a maioria "Resolvido" após as correções desta rodada).
- **11-Citações-x-Tutoria**, **07-Leitura**, **10-2**, **00-Mapa** — tabelas de
  apoio/mapeamento usadas pelas fórmulas da planilha.
- **Log de Correções (Claude)** — o log completo de todas as correções de nome
  e ajustes de duplicidade aplicados, célula a célula.

## Observações importantes

- Os números de **NPS por segmento e por unidade** em `13-Fam-Por-Segmento`
  já consideram a regra combinada que você pediu: quando um CPF responsável
  tem filhos em mais de um segmento/unidade, a nota da família é replicada
  para todos os segmentos/unidades aplicáveis (cobertura de 100% das 548
  respostas gerais/onboarding).
- Os valores `null` representam células vazias no Excel original.
- Datas foram exportadas em formato ISO 8601 (ex: `"2026-03-15T00:00:00"`).
